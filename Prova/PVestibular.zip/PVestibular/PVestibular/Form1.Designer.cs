﻿namespace PVestibular
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxMatriz = new System.Windows.Forms.ListBox();
            this.btnReceberDados = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxMatriz
            // 
            this.listBoxMatriz.FormattingEnabled = true;
            this.listBoxMatriz.ItemHeight = 20;
            this.listBoxMatriz.Location = new System.Drawing.Point(652, 44);
            this.listBoxMatriz.Name = "listBoxMatriz";
            this.listBoxMatriz.Size = new System.Drawing.Size(263, 384);
            this.listBoxMatriz.TabIndex = 0;
            // 
            // btnReceberDados
            // 
            this.btnReceberDados.Location = new System.Drawing.Point(221, 62);
            this.btnReceberDados.Name = "btnReceberDados";
            this.btnReceberDados.Size = new System.Drawing.Size(286, 81);
            this.btnReceberDados.TabIndex = 1;
            this.btnReceberDados.Text = "Receber Dados";
            this.btnReceberDados.UseVisualStyleBackColor = true;
            this.btnReceberDados.Click += new System.EventHandler(this.btnReceberDados_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(221, 164);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(286, 75);
            this.btnLimpar.TabIndex = 2;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 545);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnReceberDados);
            this.Controls.Add(this.listBoxMatriz);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxMatriz;
        private System.Windows.Forms.Button btnReceberDados;
        private System.Windows.Forms.Button btnLimpar;
    }
}

