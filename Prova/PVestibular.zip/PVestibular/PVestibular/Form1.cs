﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVestibular
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceberDados_Click(object sender, EventArgs e)
        {
            int[,] alunos = new int[6, 5];
            int totalGeral = 0;
            int totalAlunos = 0;
            string aux;
            string aux2;
            string aux3;

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    aux = Interaction.InputBox($"Total do curso:{i + 1} do ano{j + 1}: ", "InputBox");
                    if (!int.TryParse(aux, out alunos[i, j]) || alunos[i, j] <= 0)
                    {
                        MessageBox.Show("Número inválido!");

                        j--;
                    }
                    else
                    {
                        aux = "";
                        aux += $"Total curso {i + 1} do ano {j + 1} : {alunos[i, j]}";
                        totalAlunos += alunos[i, j];
                        totalGeral += alunos[i, j];
                        listBoxMatriz.Items.Add(aux);
                    }
                }
                aux2 = "";
                aux2 += $"Total curso {i + 1}: {totalAlunos}";
                listBoxMatriz.Items.Add(aux2);
            }
            aux3 = "";
            aux3 += $"Total geral: {totalAlunos}";
            listBoxMatriz.Items.Add(aux3);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBoxMatriz.Items.Clear();
        }
    }
}
