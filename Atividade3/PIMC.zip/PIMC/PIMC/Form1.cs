﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double massa, altura, resultado;

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtMassa_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtMassa_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtMassa.Text, out massa))
            {
                MessageBox.Show("Massa inválida");
            }
            else if (massa <= 0)
            {
                MessageBox.Show("Massa inválida");
                txtMassa.Focus();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
            }
            else if (massa <= 0)
            {
                MessageBox.Show("Altura inválida");
                txtAltura.Focus();
            }
        }

        private void brnCalcular_Click(object sender, EventArgs e)
        {

            resultado = massa / (altura * altura);
            resultado = Math.Round(resultado, 1);
            txtResultado.Text = resultado.ToString();

            if(resultado < 18.5)
            {
                MessageBox.Show("IMC: Menor que 18,5 \n " +
                    "Classificação: Magreza \n" + " Obesidade(GRAU): 0");
            }
            else if(resultado <=24.9)
            {
                MessageBox.Show("IMC: Entre 18,5 e 24,9 \n " +
                    "Classificação: Normal \n" + " Obesidade(GRAU): 0");
            }
            else if(resultado <= 24.9)
            {
                MessageBox.Show("IMC: Entre 18,5 e 24,9 \n " +
                   "Classificação: Normal \n" + " Obesidade(GRAU): 0");
            }
            else if (resultado <= 29.9)
            {
                MessageBox.Show("IMC: Entre 25,0 e 29,9 \n " +
                   "Classificação: Sobrepeso \n" + " Obesidade(GRAU): 1");
            }
            else if (resultado <= 39.9)
            {
                MessageBox.Show("IMC: Entre 30,0 e 39,9 \n " +
                   "Classificação: Obesidade \n" + " Obesidade(GRAU): 2");
            }
            else if (resultado > 40.0)
            {
                MessageBox.Show("IMC: Maior que 40,0 \n " +
                   "Classificação: Obesidade Grave \n" + " Obesidade(GRAU): 3");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
