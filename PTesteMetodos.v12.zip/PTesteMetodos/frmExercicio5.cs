﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int num1;
            int num2;

            num1 = Convert.ToInt16(txtNum1.Text);
            num2 = Convert.ToInt16(txtNum2.Text);

            if (num1 < num2)
            {
                Random rnd = new Random();
                int sorteado = rnd.Next(num1, num2);

                MessageBox.Show("O número sorteado entre " + num1 + " e " + num2 + " foi " + sorteado);

            }
            else
            {
                if (num1 > num2)
                {
                    MessageBox.Show("Número 1 deve ser maior que número 2");
                    txtNum1.Clear();
                    txtNum2.Clear();
                    txtNum1.Focus();

                }
            }
        }
    }
}
