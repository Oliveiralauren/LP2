﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCaracterNum_Click(object sender, EventArgs e)
        {
            char posicao;
            string msg;
            int i;
            int qtdNumericos = 0;

            for (i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                posicao = rchtxtFrase.Text[i];
                if (Char.IsNumber(posicao))
                    qtdNumericos = qtdNumericos + 1;
            }
            msg = qtdNumericos.ToString();
            MessageBox.Show(msg);
        }

        private void btnCaracterBranco_Click(object sender, EventArgs e)
        {
            string msg;
            string msgNegativa;
            char posicao;
            int i;
            int posicaoEmBranco;
            

            i = 0;
            posicaoEmBranco = 0;
            msgNegativa = "Nenhum espcaço em branco!";

            while (i < rchtxtFrase.Text.Length)
            {
                posicao = rchtxtFrase.Text[i];

                if (Char.IsWhiteSpace(posicao))
                {
                    posicaoEmBranco = i + 1;
                    msg = posicaoEmBranco.ToString();
                    MessageBox.Show(msg);
                    break;
                }
                else
                    i++;
            }
            if (i >= rchtxtFrase.Text.Length)
                MessageBox.Show(msgNegativa);
        }

        private void QtdAlfabeticos_Click(object sender, EventArgs e)
        {
            string msg;
            int qtdCarAlfa;

            qtdCarAlfa = 0;

            foreach (Char posicao in rchtxtFrase.Text)
            {
                if (Char.IsLetter(posicao))
                    qtdCarAlfa = qtdCarAlfa + 1;
            }
            msg = qtdCarAlfa.ToString();
            MessageBox.Show(msg);
        }
    }
}

