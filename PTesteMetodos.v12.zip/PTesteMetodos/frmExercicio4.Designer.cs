﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnCaracterNum = new System.Windows.Forms.Button();
            this.btnCaracterBranco = new System.Windows.Forms.Button();
            this.QtdAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(34, 37);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(854, 172);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnCaracterNum
            // 
            this.btnCaracterNum.Location = new System.Drawing.Point(55, 337);
            this.btnCaracterNum.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnCaracterNum.Name = "btnCaracterNum";
            this.btnCaracterNum.Size = new System.Drawing.Size(180, 88);
            this.btnCaracterNum.TabIndex = 1;
            this.btnCaracterNum.Text = "Quantidade de caracteres númericos";
            this.btnCaracterNum.UseVisualStyleBackColor = true;
            this.btnCaracterNum.Click += new System.EventHandler(this.btnCaracterNum_Click);
            // 
            // btnCaracterBranco
            // 
            this.btnCaracterBranco.Location = new System.Drawing.Point(343, 337);
            this.btnCaracterBranco.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnCaracterBranco.Name = "btnCaracterBranco";
            this.btnCaracterBranco.Size = new System.Drawing.Size(170, 88);
            this.btnCaracterBranco.TabIndex = 2;
            this.btnCaracterBranco.Text = "Primeiro caracter branco";
            this.btnCaracterBranco.UseVisualStyleBackColor = true;
            this.btnCaracterBranco.Click += new System.EventHandler(this.btnCaracterBranco_Click);
            // 
            // QtdAlfabeticos
            // 
            this.QtdAlfabeticos.Location = new System.Drawing.Point(606, 337);
            this.QtdAlfabeticos.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.QtdAlfabeticos.Name = "QtdAlfabeticos";
            this.QtdAlfabeticos.Size = new System.Drawing.Size(193, 88);
            this.QtdAlfabeticos.TabIndex = 3;
            this.QtdAlfabeticos.Text = "Quantidade de caracteres alfabéticos";
            this.QtdAlfabeticos.UseVisualStyleBackColor = true;
            this.QtdAlfabeticos.Click += new System.EventHandler(this.QtdAlfabeticos_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1542, 1031);
            this.Controls.Add(this.QtdAlfabeticos);
            this.Controls.Add(this.btnCaracterBranco);
            this.Controls.Add(this.btnCaracterNum);
            this.Controls.Add(this.rchtxtFrase);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnCaracterNum;
        private System.Windows.Forms.Button btnCaracterBranco;
        private System.Windows.Forms.Button QtdAlfabeticos;
    }
}