﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMat00030482123006
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int indice;
            double[] vetorA = new double[10] { 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00 };
            double[] vetorB = new double[10];
            for (indice = 0; indice < 10; indice++)
            {
                if (indice % 2 == 0)
                    vetorB[indice] = vetorA[indice] + 5;
                else
                    vetorB[indice] = vetorA[indice] * 5;


                ListBox.Items.Add("Vetor A: " + vetorA[indice].ToString("N2") + " Vetor B: " + vetorB[indice].ToString("N2"));
            }
        }
    }
}
