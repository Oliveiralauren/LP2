﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void FrmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            string nome, cargo;
            double A, prod, grat, salario, matricula, salBruto;
            int B, C, D;

            nome = txtnome.Text;
            cargo = txtcargo.Text;

            if (nome == String.Empty || cargo == String.Empty)
            {
                MessageBox.Show("Nome e cargo precisam estar preenchidos");
            }

            else if (!double.TryParse(txtgratificacao.Text, out grat) || !double.TryParse(txtsalario.Text, out salario) ||
                     !double.TryParse(txtproducao.Text, out prod) || !double.TryParse(txtmatricula.Text, out matricula))
                MessageBox.Show("Produção/Salario/Matricula/Gratificação precisam ser numeros");
            else
            {
                A = salario;
                B = prod >= 100 ? 1 : 0;
                C = prod >= 120 ? 1 : 0;
                D = prod >= 150 ? 1 : 0;

                salBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + grat;

                if (salBruto > 7000 && prod >= 150)
                    lblresultado.Text = $"Seu salario bruto é R${salBruto}";
                else if (salBruto > 7000)
                {
                    salBruto = 7000;
                    lblresultado.Text = $"Seu salario bruto é de {salBruto}";
                }
                else
                {
                    lblresultado.Text = $"Seu salario bruto é de {salBruto}";
                }
            }
    }
    }
}

