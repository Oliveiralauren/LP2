﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        Double salarioBruto, nome;



        private void msbkSalario_Validated(object sender, EventArgs e)
        {
            if (mskbxSalBruto.Text == "")
                mskbxSalBruto.Text = null;

            else
                   if (!Double.TryParse(mskbxSalBruto.Text, out salarioBruto))
                MessageBox.Show("Insira um Salário Válido");
            else
               if (salarioBruto == 0)
                MessageBox.Show("Digite um valor maior que 0");
        }

        private void msbkNome_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxNome.Text, out nome))
                Convert.ToString(mskbxNome.Text);
            else
            {
                MessageBox.Show("Digite um nome válido");
                mskbxNome.Text = "";
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            double descontoINSS, descontoIRPF, salFamilia, salLiquido;

            if (mskbxNome.Text == "")
            {
                MessageBox.Show("Digite o nome do funcionário");
                mskbxNome.Focus();
            }
            else
                if (mskbxSalBruto.Text == "")
            {
                MessageBox.Show("Digite um valor para o salário bruto");
                mskbxSalBruto.Focus();
            }
            else
            {
             //INSS

                if (salarioBruto <= 800.47)
                {
                    txtINSS.Text = "7,65%";
                    descontoINSS = 0.0765 * salarioBruto;
                    txtDescINSS.Text = "R$ " + Convert.ToString(descontoINSS);
                }
                else
                {
                    if (salarioBruto <= 1050)
                    {
                        txtINSS.Text = "8,65%";
                        descontoINSS = 0.0865 * salarioBruto;
                        txtDescINSS.Text = "R$ " + Convert.ToString(descontoINSS);
                    }
                else
                    {
                        if (salarioBruto <= 1400.77)
                        {
                            txtINSS.Text = "9,00%";
                            descontoINSS = 0.09 * salarioBruto;
                            txtDescINSS.Text = "R$ " + Convert.ToString(descontoINSS);
                        }
                else
                        {
                            if (salarioBruto <= 2801.56)
                            {
                                txtINSS.Text = "11,00%";
                                descontoINSS = 0.11 * salarioBruto;
                                txtDescINSS.Text = "R$ " + Convert.ToString(descontoINSS);
                            }
                else
                            {
                             txtINSS.Text = "Teto";
                             descontoINSS = 308.17;
                             txtDescINSS.Text = "R$ " + Convert.ToString(descontoINSS);
                            }

                            //IRPF
                            if (salarioBruto <= 1257.12)
                            {
                                txtINSS.Text = "0,00%";
                                descontoIRPF = 0;
                                txtDescIRPF.Text = "Isento";
                            }
                            else
                                   if (salarioBruto <= 2512.08)
                            {
                                txtIRPF.Text = "15,00%";
                                descontoIRPF = salarioBruto * 0.15;
                                txtDescIRPF.Text = "R$ " + Convert.ToString(descontoIRPF);
                            }
                            else
                            {
                                txtIRPF.Text = "27,50%";
                                descontoIRPF = salarioBruto * 0.275;
                                txtDescIRPF.Text = "R$ " + Convert.ToString(descontoIRPF);
                            }

                            //Salário Familia


                        }
                    }
                }
            }
        }

            private void Form1_Load(object sender, EventArgs e)
            {

            }
        }
    }
