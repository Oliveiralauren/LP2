﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (txtB.Text.Length == 0)
                txtB.Text = "";
            else
               if (!Double.TryParse(txtB.Text, out ladoB))
                MessageBox.Show("Insira um número válido");

            else
               if (ladoB <= 0)
            {
                MessageBox.Show("Valor deve ser maior que zero");
                txtB.Text = null;
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (txtC.Text.Length == 0)
                txtC.Text = "";
            else
                if (!Double.TryParse(txtC.Text, out ladoC))
                MessageBox.Show("Insira um número válido");

            else
                if (ladoC <= 0)
            {
                MessageBox.Show("Valor deve ser maior que zero");
                txtC.Text = null;
                txtC.Focus();
            }
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if (txtA.Text.Length == 0 || txtB.Text.Length == 0 || txtC.Text.Length == 0)
                MessageBox.Show("Insira um número");
            else
                if ((ladoA < ladoB + ladoC) && (ladoA > ladoB - ladoC) && (ladoB < ladoA + ladoC) && (ladoB > ladoA - ladoC) && (ladoC < ladoA + ladoB) && (ladoC > ladoA - ladoB))
            {

                if ((ladoA == ladoB) && (ladoB == ladoC))
                    MessageBox.Show("Triângulo Equilatero");
                else
                    if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                    MessageBox.Show("Triângulo Isósceles");

                else
                    MessageBox.Show("Triângulo Escaleno");
            }

            else
            {
                MessageBox.Show("Não é Triângulo");
                txtA.Text = null;
                txtB.Text = null;
                txtC.Text = null;
                txtA.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (txtA.Text.Length == 0)
                txtA.Text = "";

            else
                if (!Double.TryParse(txtA.Text, out ladoA))
                MessageBox.Show("Insira um número válido");

            else
                if (ladoA <= 0)
            {
                MessageBox.Show("Valor deve ser maior que zero");
                txtA.Text = null;
                txtA.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
